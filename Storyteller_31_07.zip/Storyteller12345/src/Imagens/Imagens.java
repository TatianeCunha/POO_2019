package Imagens;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class Imagens extends JFrame{
    
}
